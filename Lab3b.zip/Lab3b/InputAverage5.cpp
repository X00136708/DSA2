#include <iostream> 
#include <stdio.h>
using namespace std;
void inputAndAverage5();
int main() {
	inputAndAverage5();
	return 0;
}
void inputAndAverage5() {
	double num1, num2, num3, num4, num5;
	cout << "Enter 5 numbers: ";
	cin >> num1 >> num2 >> num3 >> num4 >> num5;
	double array[5] = { num1, num2, num3, num4, num5 };
	double total = array[0] + array[1] + array[2] + array[3] + array[4];
	double average = total / 5;
	cout << "Total: " << total << endl << "Average: " << average << endl;
	for (int i = 0; i < 5; i++) {
		double num = array[i];
		 num = average - num;
		cout << "To make " << array[i] << " reach the average of " << average << ", modify it by: " << num << endl;
	}
}