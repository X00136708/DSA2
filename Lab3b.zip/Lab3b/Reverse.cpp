#include <iostream>
using namespace std;
void print(char *, int);
int main() {
	int counter = 0;
	char array[50];
	char input;
	do {
		cout << "Enter a character: ";
		cin >> input;
		array[counter] = input;
		counter++;
		

	} while (input != '.');

	print(array, counter);
}
void print(char array[], int counter) {

	for (int i = 0; i < (counter / 2); i++) {
		float temp = array[i];                
		array[i] = array[(counter - 1) - i];
		array[(counter - 1) - i] = temp;
	}
	//understood the avoce for loop from http://www.cplusplus.com/forum/beginner/189483/. I learned it and can now replicate it
	for (int i = 0; i < counter; i++) {
		cout << "Values: " << array[i] << endl;
	}
}