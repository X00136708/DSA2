#include <iostream>
using namespace std;
void fillArray(char *);
int main() {
	char array[100];
	fillArray(array);
	}

void fillArray(char array[]) {
	char input;
	int counter = 0;
	int size = 100;


	do {
		cout << "Enter a character ('.' to exit): ";
		cin >> input;
		array[counter] = input;
		counter++;



	} while (input != '.');
	cout << "Array size: " << counter - 1 << "/" << size << endl;
	for (int i = 0; i < counter - 1; i++) {
		cout << "Array details: " << array[i] << endl;
	}
		if (input == '.') {
			cout << "True";
		}
		else {
			cout << "False";
		}

		

	
}

