#include <iostream>
using namespace std;
void fillArray(char *);
void print(char *, int);

int main() {
	char array[100];
	fillArray(array);
}

void fillArray(char array[]) {
	char input;
	int counter = 0;
	int size = 100;


	do {
		cout << "Enter a character ('.' to exit): ";
		cin >> input;
		array[counter] = input;
		counter++;



	} while (input != '.');
	
	if (input == '.') {
		cout << "True" << endl;
	}
	else {
		cout << "False" << endl;
	}
	print(array, counter);
}

	void print(char array[], int counter) {

		for (int i = 0; i < (counter / 2); i++) {
			float temp = array[i];
			array[i] = array[(counter - 1) - i];
			array[(counter - 1) - i] = temp;
		}
		//understood the avoce for loop from http://www.cplusplus.com/forum/beginner/189483/. I learned it and can now replicate it
		for (int i = 0; i < counter; i++) {
			cout << "Values: " << array[i] << endl;
		}
	}



