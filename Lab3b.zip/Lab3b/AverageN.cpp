#include <iostream>

using namespace std;

void average5(double[], int);
int main() {
	int size;
	double * array;
	
	cout << "Enter the amount of numbers you want to calculate for: ";
	cin >> size;
	array = new double[size];
	average5(array, size);
	
	
}

void average5(double array[], int size) {
	

	for (int i = 0; i < size; i++) {
		cout << "Enter number " << i + 1 << endl;
		cin >> array[i];
	}
	

	double total = 0;
	for (int i = 0; i < size; i++) {
		total += array[i];
	}
	
	double average = total / size ;
	cout << "Total: " << total << endl << "Average: " << average << endl;
	for (int i = 0; i < size;i++) {
		double num = array[i];
		num = average - num;
		cout << "To make " << array[i] << " reach the average of " << average << ", modify it by: " << num << endl;

	}
}