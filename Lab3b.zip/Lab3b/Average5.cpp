#include <iostream>
using namespace std;
void average5(int[]);
int main() {
	cout << "Enter 5 numbers: ";
	int num1, num2, num3, num4, num5;
	cin >> num1 >> num2 >> num3 >> num4 >> num5;
	int array[5];
	array[0] = num1;
	array[1] = num2;
	array[2] = num3;
	array[3] = num4;
	array[4] = num5;
	average5(array);
}

void average5(int array[]) {
	double total = 0;
	for (int i = 0; i < 5; i++) {
		total += array[i];
	}
	double average = total / 5;
	cout << "Total: " << total << endl << "Average: " << average << endl;
	for (int i = 0; i < 5; i++) {
		double num = array[i];
		num = average - num;
		cout << "To make " << array[i] << " reach the average of " << average << ", modify it by: " << num << endl;
		
	}
}